sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageToast",
],
function (Controller, MessageToast) {
    "use strict";

    return Controller.extend("student00.com.sap.training.advancedsapui5.simpleapp.controller.Main", {
        onInit: function () {
            let sPath = "/UX_C_Carrier_TP('AA')";
            this.getView().bindElement(sPath);
        },

        onHover: function(evt) {
            var sText = this.getOwnerComponent().getModel("i18n").getProperty("msgSeatsAv");
            MessageToast.show(evt.getSource().getHoverText() + " " + sText, {duration: 1000}); 
          }
    });
});

sap.ui.define(
    [
        "sap/ui/core/mvc/Controller"
    ],
    function(BaseController) {
      "use strict";
  
      return BaseController.extend("student00.com.sap.training.advancedsapui5.simpleapp.controller.App", {
        onInit: function() {
        }
      });
    }
  );
  
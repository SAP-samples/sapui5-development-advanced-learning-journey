/* global QUnit */

sap.ui.require(["student00/com/sap/training/advancedsapui5/simpleapp/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});

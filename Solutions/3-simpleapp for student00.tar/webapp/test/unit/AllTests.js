sap.ui.define([
	"student00comsaptrainingadvancedsapui5/simpleapp/test/unit/controller/Main.controller"
], function () {
	"use strict";
});

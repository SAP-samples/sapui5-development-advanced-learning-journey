sap.ui.define([
    "sap/ui/core/mvc/Controller"
],
function (Controller) {
    "use strict";

    return Controller.extend("student.com.sap.training.advancedsapui5.qunit.controller.Main", {
        onInit: function () {

        }
    });
});

sap.ui.define([
	"studentcomsaptrainingadvancedsapui5/qunit/test/unit/controller/Main.controller",
	"student/com/sap/training/advancedsapui5/qunit/test/unit/model/Formatter"
], function () {
	"use strict";
});

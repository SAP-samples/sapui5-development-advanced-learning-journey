sap.ui.predefine(
	'student00/com/sap/training/advancedsapui5/uicontrols/library',
	['sap/ui/core/Core', 'sap/ui/core/library'], 
	
	function(Core, coreLib) {
	sap.ui.getCore().initLibrary({
		name: 'student00.com.sap.training.advancedsapui5.uicontrols',
		noLibraryCSS: true
	});
	return student00.com.sap.training.advancedsapui5.uicontrols;
});

jQuery.sap.registerPreloadedModules({
	"version":"2.0",
	"name":"student00.com.sap.training.advancedsapui5.uicontrols"
});

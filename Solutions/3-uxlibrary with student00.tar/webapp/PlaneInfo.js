sap.ui.define([
    "sap/ui/core/Control",
     "student00/com/sap/training/advancedsapui5/uicontrols/PlaneInfoRenderer"
  ],
  
    function (Control, PlaneInfoRenderer) {
      "use strict";
  
      return Control.extend("student00.com.sap.training.advancedsapui5.uicontrols.PlaneInfo", {
        metadata:{
            properties: {
              "seatsMax" : {
                type: "string"
              },
              "seatsOcc" : {
                type: "string"
              }
            }
        },
        renderer: PlaneInfoRenderer
      });
    }
  );
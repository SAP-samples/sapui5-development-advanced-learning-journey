sap.ui.define(["sap/ui/thirdparty/jquery","sap/ui/core/library"],
    function(jquery,library) {
      "use strict";
    
      sap.ui.getCore().initLibrary({
        name:"student00.com.sap.training.advancedsapui5.uicontrols",
        version:"1.0.0",
        dependencies: ["sap.ui.core"],
          types:[],
          interfaces: [],
          controls: [
            "student00.com.sap.training.advancedsapui5.uicontrols.PlaneInfo",
            "student00.com.sap.training.advancedsapui5.uicontrols.HoverButton",
            "student00.com.sap.training.advancedsapui5.uicontrols.PlaneInfoRenderer"
          ],
        elements: [
        
        ],
        noLibraryCSS: true 
       });
    
      return student00.com.sap.training.advancedsapui5.uicontrols;
    }, /*bExport*/ false);